document.addEventListener("DOMContentLoaded", function dashboard() {
    //Set up loading spinner
     var opts = {
         lines: 13,
         length: 22,
         width: 9,
         radius: 30,
         corners: 1,
         rotate: 2,
         direction: 1,
         speed: 1,
         trail: 60,
         shadow: false,
         hwaccel: false,
         className: 'spinner',
         zIndex: 2e9,
         top:'17%',
         left: '50%'
     };
   
     var target = document.getElementById("spinner");
     var spinner = new Spinner(opts).spin(target);
     queue()
            .defer(d3.json, "data/cantones_ec.geojson") //neighbourhoodsGejson
            .defer(d3.json, "data/data1.json")     //datajson
            .await(renderCharts);
  
     function renderCharts(error, neighbourhoodsGejson, dataJson) {
 
         if(error) throw error;
         
         //cleaned data
         var data  = dataJson.data;
 
         //Crossfilter instance
         var ndx = crossfilter(data);
 
         //Define values to be used by chart(s)
         var chartHeightScale = 0.58,
             pieXscale        = 1.41,
             pieRscale        = chartHeightScale * 0.5,
             pieInnerRscale   = pieRscale * 0.52,
             monthNames       = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
             countSum         = data.map(function(d) { return d.COUNT; })
                                    .reduce(function(sum, value) { return sum + value; }, 0 ),
             map, info, mapReset, title, texts, chartTexts, slideMenu;
 
         //Colors and color scales
         //Got the colors from http://colorbrewer2.org
         var pieColors         = ["#66c2a5", "#fc8d62", "#8da0cb", "#e78ac3", "#a6d854"],
             mapColors         = ["#a6cee3","#1f78b4","#b2df8a","#33a02c","#fb9a99","#e31a1c","#fdbf6f","#ff7f00"],
             bubbleColors      = ["#a6cee3", "#1f78b4", "#b2df8a", "#33a02c"],
             pieScaleColors    = d3.scale.quantize().domain([0, pieColors.length - 1]).range(pieColors),
             bubbleScaleColors = d3.scale.quantize().domain([0, bubbleColors.length - 1]).range(bubbleColors);
 
         //Define Dimensions
         var neighbourhoodsDim = ndx.dimension(function(d) { return d.CANTON; }),
             complaintsDim     = ndx.dimension(function(d) { return d.COMPLAINT; }),
             monthDim          = ndx.dimension(function(d) { return monthNames[d["MONTH_NUMBER"] - 1]; }),
             yearDim           = ndx.dimension(function(d) { return d.RELACION; }),
             initiatorDim      = ndx.dimension(function(d) { return [d["INITIATED_BY"], d.STATUS]; });
 
         //Define groups
         var groupByCount        = function(d) { return d.COUNT; },
             neighbourhoodsGroup = neighbourhoodsDim.group().reduceSum(groupByCount),
             complaintsGroup     = complaintsDim.group().reduceSum(groupByCount),
             monthGroup          = monthDim.group().reduceSum(groupByCount),
             yearGroup           = yearDim.group().reduceSum(groupByCount),
             statusGroup         = initiatorDim.group().reduceSum(groupByCount),  
             sumofAllInfractions = ndx.groupAll().reduceSum(groupByCount); 
 
         //Charts, selections, and filterCount(no var to be detected by reset link)
         //find better solution to make code secure("use strict wont allow this")
             dcMap               = dc.leafletChoroplethChart("#map-plot"),
             barChart            = dc.barChart("#bar-chart"),
             rowChart            = dc.rowChart("#row-chart");
         var recordCounter       = dc.dataCount("#records-count"),       
             charts, neighbourSelections;
 
         recordCounter.dimension(ndx)
                      .group(ndx.groupAll())
                      .html({some:'<strong>%filter-count</strong> selected out of <strong>%total-count</strong> records. | '+
                                  '<a href= "javascript:dc.filterAll(); dc.redrawAll();">Reset All</a>',
                             all: 'Todos los registros seleccionados. Haga clic en los gráficos para aplicar filtros.'
                            });
         recordCounter.render();
 
         charts = [dcMap, barChart, rowChart];
 
         //add filter listerner to update sum and percentage text
         // for all the charts
         charts.forEach(statsUpdate);
 
         dcMap
              .dimension(neighbourhoodsDim)
              .group(neighbourhoodsGroup)          
              .mapOptions({
                 center:          [-1.350, -78.622],
                 zoom:            7,
                 scrollWheelZoom: false,
                 minZoom:         6,
                 maxZoom:         16,
                 touchZoom:       false
              })
              .geojson(neighbourhoodsGejson)
              .valueAccessor(function(d) { return d.value; })
              .colors(mapColors)
              .colorAccessor(function(d) { return d.value; })
              .featureKeyAccessor(function(feature) { return feature.properties.name; })
              .legend(dc.leafletLegend().position("bottomright"))
              .on("renderlet.dcMap",  function infractionMapInfoUpdate(chart, filter) {
                 eventTrigger(function updater() {
                     //get all the feature layers
                     var eArray = Object.values(chart.map()._layers)
                     .filter(function(e) { if( e.hasOwnProperty("feature") ) return e; } );
 
                     //get path(layer) popupContent and update the map info
                     eArray.forEach(function(layer) {
                         chart.map()._layers[layer._leaflet_id].on("mouseover", function() { 
 
                             info.update(layer);
                         });
                     });
                 });
              })
              .on("preRender.dcMap", colorUpdate)
              .on("preRedraw.dcMap", colorUpdate);
 
         rowChart.dimension(yearDim)
                 .group(yearGroup)
                 .height(setHeight(rowChart))
                 .margins(chartMargin(rowChart, {top: 0.02, right: 0.02, bottom: 0.10, left:0.02}))
                 .useViewBoxResizing(true)
                 .label(function(d) { return d.key; })
                 .title(function(d) { return d.value.toLocaleString(); })
                 .elasticX(true)
                 .on("pretransition.xAxis", fontSizeUpdate("row-chart"));
         rowChart.xAxis().ticks(6);        
 
         barChart.dimension(monthDim)
                 .group(monthGroup)
                 .height(setHeight(barChart))
                 .margins(chartMargin(barChart, {top: 0.02, right: 0.02, bottom: 0.10, left:0.12}))
                 .useViewBoxResizing(true)
                 .title(function(d) { return d.value.toLocaleString(); })
                 .x(d3.scale.ordinal().domain(monthNames))
                 .xUnits(dc.units.ordinal)
                 .elasticY(true)
                 .on("pretransition.Axis", fontSizeUpdate("bar-chart"));
         barChart.xAxis().ticks(6);           
 
         
 
         dc.renderAll();
 
         //Choropleth map
         map = dcMap.map();
 
         //reset map location when window is resized
         map.on("resize", function(e) { map.setZoom(10).getBounds().getCenter(); });
 
         //----------------------------Additions to leaflet map----------------------------
         //SlideMenu, dc reset, and map info
         //https://github.com/unbam/Leaflet.SlideMenu
         title     = '<h3>Selección de vecindario</h3>',
         contents  = '<div id="selection" class="svg-container"></div>',
         slideMenu = L.control.slideMenu('', {position: 'topright', menuposition: 'topright', width: '70%', height: '45%', delay: '50'}).addTo(map);
 
         slideMenu.setContents(title + contents);
 
         //http://leafletjs.com/examples/choropleth.html
         info       = L.control({position: "bottomleft"});
         info.onAdd = function(map) {
             this._div = L.DomUtil.create("div", "myinfo");
             this.update();
             return this._div;
         };
         info.update = function(e) {
             this._div.innerHTML = "<span><strong>Infracciones de vecindario</strong></span><br>" + (e ? 
             "<span>"+e._popupContent+"</span>": "Coloca el cursor sobre una región del mapa");
         };
 
         info.addTo(map);
 
         neighbourSelections = dc.selectMenu("#selection");
 
         //add filter listerner to update sum and percentage text
         statsUpdate(neighbourSelections);
 
         neighbourSelections.dimension(neighbourhoodsDim)
                             .group(neighbourhoodsGroup)
                             .multiple(true)
                             .numberVisible(11)
                             .controlsUseVisibility(true)
                             .order(function (a,b) { return a.value > b.value ? 1 : b.value > a.value ? -1 : 0; }); 
         neighbourSelections.render();
         //----------------------------Additions to leaflet map----------------------------
     
         //---------------------------Addition to Pie Chart Sum and Percentage Stats---------------------------
         
         //---------------------------Addition to Pie Chart Sum and Percentage Stats---------------------------
     
         //------------Font Size for legend and label texts------------
         
         //------------Font Size for axis and label texts------------
 
         d3.select("#spinner").remove(); //remove spinner after files and charts are loaded
 
         function setHeight(chart) { return chart.width() * chartHeightScale; };
 
           
 
         function statsUpdate(chart) {
             chart.on("filtered." + chart.chartID(), function() {
                 eventTrigger(function htmlUpdater() {
                     //update the sum text
                     d3.select("#sum").html( sumofAllInfractions.value().toLocaleString() );
 
                     //update the percent text
                     d3.select("#percent").html( ((sumofAllInfractions.value()/countSum) * 100).toFixed(3) );
                 });
             });
         };  
         
         function colorUpdate(chart, filter) {
             eventTrigger(function() {
                 //update color domain to correspond with user filters
                 chart.calculateColorDomain( d3.extent(chart.group().all(), chart.valueAccessor()) ); 
             });
  
          };
 
          function fontSizeUpdate(chartId) {
             return function(chart, filter) {
                         eventTrigger(function sizeUpdater() {
                             chart.selectAll("#"+chartId+" g.tick text")
                                  .style("font-size", Math.round(chart.height() * 0.05, 1));
                         });
                     };
         };
 
         function chartMargin(chart, margin) {
             return {
                         top:    Math.round(chart.height() * margin.top , 1),
                         right:  Math.round(chart.width() * margin.right , 1),
                         bottom: Math.round(chart.height() * margin.bottom , 1),
                         left:   Math.round(chart.width() * margin.left , 1)
                     };
         };
 
         function eventTrigger(func){
             return dc.events.trigger(func);
         };
 
     }; //renderCharts
 })//document.addEventListener
      
 